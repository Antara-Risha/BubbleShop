<div class="sb-sidenav-menu-heading">Interface</div>
<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
    Laundry
    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
</a>
<div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
    <nav class="sb-sidenav-menu-nested nav">
        <a class="nav-link" href="#">Order Form</a>
        <a class="nav-link" href="#">Order History</a>
    </nav>
</div>

<div class="sb-sidenav-menu-heading">Settings</div>
<!-- <a class="nav-link" href="{{ route('users.index') }}">
    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
    Users
</a> -->
<a class="nav-link" href="#">
    <div class="sb-nav-link-icon"><i class="fas fa-lock"></i></div>
    Change Password
</a>
